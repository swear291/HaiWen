package AR
import jodd.typeconverter.Convert
import org.apache.spark.mllib.fpm.FPGrowth
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.rdd.RDD
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable
import scala.util.Random

object Main {

  var testString=""


  var inputFileUrl:String=""
  var userDataUrl:String=""
  var outputFileUrl:String=""
  val minSupport=0.092
  val minConfidence=0.0
  //�洢Ƶ���
  val freqHashMap:mutable.HashMap[String,Long]=new mutable.HashMap[String,Long]()
  //�洢����ʽ
  val symbolHashMap:mutable.HashMap[(Int,Int),String]=new mutable.HashMap[(Int,Int),String]()
  //�洢��������
  val rulesHashMap:mutable.HashMap[String,mutable.ArrayBuffer[(String,Double)]]=new mutable.HashMap[String,mutable.ArrayBuffer[(String,Double)]]

  def main(args: Array[String]): Unit = {
    inputFileUrl=args(0)
    userDataUrl=args(1)
    outputFileUrl=args(2)

    val conf = new SparkConf
    conf.setAppName("AR")
    conf.set("spark.default.parallelism", "600")
    val sc = new SparkContext(conf)
    val data = sc.textFile(inputFileUrl)
    val userData = sc.textFile(userDataUrl)
    val transactions: RDD[Array[String]] = data.map(s => s.trim.split(' '))
    val count=transactions.count()
    val minSupportCount=count*minSupport
    val words: RDD[String] = data.flatMap(s => s.trim.split(' '))
    val userHistory: RDD[Array[String]] = userData.map(s => s.trim.split(' ')).repartition(111)
    val pairs = words.map(word => (word, 1))
    val wordsCount = pairs.reduceByKey(_ + _).filter(x=>{
      var flag=false
      if(x._2>minSupportCount){
       flag=true
      }
      flag
    })

    val wordCountArray=wordsCount.collect().sortWith(_._2<_._2)
    val wordsArray=wordsCount.keys.collect()
    val simpleTrans = transactions.map(x => {
      x.filter(str => {
        wordsArray.contains(str)
      })
    }).repartition(111).persist()


    //simpleTrans.saveAsTextFile("hdfs://192.168.1.150:8020/arout/simple")
    val groupSize=1
    for(index <- Range(0,wordCountArray.length,groupSize)) {
      //for(j<- 0 to firstFreqCount-1 if j!=index){
      val tmpFilterArr=wordCountArray.slice(0,index).map(_._1)
      var minSimpleTrans=simpleTrans
      if(index>0){
        minSimpleTrans=simpleTrans.map(x=>{
          x.filter(str => {
            !tmpFilterArr.contains(str)
          })
        })
      }


      val tmpArr=wordCountArray.slice(index,index+groupSize)
      val currTrans = minSimpleTrans.filter(x => {
        //getIsFit(tmpArr,x)
        x.contains(wordCountArray(index)._1)
      })

      //currTrans.saveAsTextFile("hdfs://192.168.1.150:8020/arout/"+wordCountArray(index)._1)
      val currCount = currTrans.count()


      if (currCount >= minSupportCount) {

        val fpg = new FPGrowth()
          .setMinSupport(minSupportCount*1.0 / currCount)
        val model = fpg.run(currTrans)

        println("------------------------------\n" +
          "--------please wait-----------\n" +
          "--------�����" +(index+1)+"/"+wordCountArray.length+"----------\n"+
          "---��ǰ����"+wordCountArray(index)._1+"-ӳ�����ݼ�-----\n"+
          "---��ǰ�������ݸ�����"+currCount+"------"
        )

        //println("��ǰ���ݼ�")
        //currTrans.collect().foreach(x=>{println(x.mkString(","))})
        model.freqItemsets.filter(x => {
          x.items.contains(wordCountArray(index)._1)
        }).collect().foreach { itemset =>
          val key = itemset.items.sortWith(_.toLong<_.toLong).mkString(",")
          val count = itemset.freq
          if (!freqHashMap.contains(key)) {
            freqHashMap.put(key, count)
          }

        }
      }

//      simpleTrans = simpleTrans.map {
//        x => {
//          x.filter(str=>{
//            !tmpArr.contains(str)
//          })
//        }
//      }

      //}
    }


    sc.parallelize(freqHashMap.toArray.sortWith(_._2<_._2)).map(x=>{
        x._1.replace(","," ")
    }).saveAsTextFile(outputFileUrl+"/freq")

    //������������
    var confidence=0.0
    freqHashMap.foreach(x=>{
      var arr=x._1.split(",")
      if(arr.length>1){
        var left=new mutable.ArrayBuffer[String]()
        left=left++=arr
        arr.foreach(right=>{
          val key=(left-right).mkString(",")
          confidence=x._2*1.0/freqHashMap(key)
          if(rulesHashMap.contains(key)){
            rulesHashMap(key)=rulesHashMap(key)+=((right,confidence))
          }else{
            rulesHashMap.put(key,new mutable.ArrayBuffer[(String, Double)]().+=((right,confidence)))
          }

        })
      }

    })
    //sc.parallelize(rulesHashMap.toSeq).saveAsTextFile("hdfs://192.168.1.150:8020/arout/rules")


    val rulesSetHashMap=sc.parallelize(rulesHashMap.toSeq).map(x=>{
      (x._1.split(",").toSet,x._2)
    }).collect()
    val userHistorySet=userHistory.map(x=>{
      x.toSet
    })
    //�Ƽ�
    val broadcastedRules=sc.broadcast(rulesSetHashMap)
    var result=new mutable.ArrayBuffer[String]()
    val recommendResult=userHistorySet.map(x=>{
      var itemTop="0"
      var maxConfidence=0.0
      broadcastedRules.value.foreach(rule=>{
        if(rule._1.subsetOf(x)) {
          rule._2.foreach(rightItem => {
            if (!x.contains(rightItem._1)) {
              if (rightItem._2 > maxConfidence) {
                itemTop = rightItem._1
                maxConfidence = rightItem._2
              } else if (rightItem._2 == maxConfidence) {
                if (rightItem._1.toLong < itemTop.toLong) {
                  itemTop = rightItem._1
                }
              }
            }
          })
        }

      })
      itemTop
    })


    recommendResult.saveAsTextFile(outputFileUrl+"/rec")


  }

  //�ж�x�Ƿ���y���Ӽ�
  def getIsContain(x:Array[String],y:Array[String]): Boolean ={
    var flag=true
    if(x.length<=y.length){
      for(i<- x.indices if flag){
        if(!y.contains(x(i))){
          flag=false
        }
      }
    }else{
      flag=false
    }
    flag
  }

  //�ж��Ƿ�����ɸѡ����
  def getIsFit(x:Array[(String,Int)],y:Array[String]): Boolean ={
    var flag=false
    for(i <- x.indices if !flag){
      if(y.contains(x(i)._1)){
        flag=true
      }
    }
    flag
  }











}