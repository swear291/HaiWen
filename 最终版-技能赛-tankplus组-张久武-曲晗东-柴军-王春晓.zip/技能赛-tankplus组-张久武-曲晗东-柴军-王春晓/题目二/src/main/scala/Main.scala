package FD
import java.util
import java.io.FileWriter

import org.apache.spark.SparkConf
import org.apache.spark.SparkContext
import org.apache.spark.sql.{Column, DataFrame, SQLContext}

import scala.collection.mutable
import scala.util.control.Breaks._
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer


object Main {
  var result=""
  val groupCountPairs:mutable.HashMap[Long,Long]=new mutable.HashMap[Long,Long]()
  var canGroups=new mutable.HashMap[Long,mutable.HashMap[Long,util.ArrayList[Long]]]()
  var totalDepth=0
  val groupCountMap=new mutable.HashMap[mutable.HashSet[String],Long]()
  val functionMap=new mutable.HashMap[String,mutable.ListBuffer[mutable.HashSet[String]]]()
  val reFunctionMap=new mutable.HashMap[mutable.HashSet[String],mutable.ListBuffer[String]]()
  var listbf=new mutable.HashMap[Int,Iterator[scala.collection.mutable.HashSet[String]]]

  def main(args: Array[String]){
    var inputFileUrl:String=args(0)
    var outputFileUrl:String=args(1)

    val conf = new SparkConf
    conf.setAppName("FD")
    conf.set("spark.default.parallelism", "600")
    conf.set("spark.debug.maxToStringFields", "1000")

    val sc = new SparkContext(conf)
    val dataFrame=readDataFromCsv(inputFileUrl,sc).dropDuplicates().persist(StorageLevel.MEMORY_ONLY)
    val colCount = dataFrame.columns.length
    val colPair=getColFlag(colCount)
    if(colCount<20){
      //获得候选集分组
      canGroups=getGroups(colPair)
      for (i <- 0 to colCount-1){
        val columnName= "_c"+(colCount-i-1)
        val candidates=canGroups.get(colPair(columnName)).get
        //将数据重新分块，并缓存
        val newDataFrame=dataFrame.repartition(112,new Column(columnName)).persist(StorageLevel.MEMORY_ONLY)
        //对每一分组进行验证
        FD_discover(candidates,newDataFrame,colPair,columnName)
        newDataFrame.unpersist()
      }
      //将结果转化为固定格式，并保存到hdfs
      translateCandidates(canGroups,colPair,outputFileUrl,sc)
    }else{

      val rawdataFrame = readDataFromCsv(inputFileUrl, sc).dropDuplicates().persist(StorageLevel.MEMORY_ONLY)
      val nameMap=new mutable.HashMap[String,String]()
      totalDepth=rawdataFrame.columns.length-1

      val columnName=rawdataFrame.columns
      for(i<-columnName.indices){
        nameMap.put(columnName(i),"column"+(i+1))
      }

      var allColumn=new mutable.ArrayBuffer[mutable.HashSet[String]]()

      columnName.foreach(x=>{
        val tmp=new mutable.HashSet[String]()
        tmp.add(x)

        allColumn=allColumn.+=(tmp)
      })

      allColumn.foreach(col=>{
        val count=rawdataFrame.groupBy(col.toList.head,col.toList:_*).count().count()
        groupCountMap.put(col,count)
      })



      for(right<- allColumn){
        val dataFrame=rawdataFrame.repartition(112,new Column(right.toList.head)).persist(StorageLevel.MEMORY_ONLY)
        val restCol=allColumn-right
        val rightStr=right.toList.head
        var leftCount=0L
        var allCount=0L
        var removeSet=new mutable.ArrayBuffer[mutable.HashSet[String]]()


        var currColSets=restCol

        while (currColSets.size>0){
          currColSets.foreach(left=>{

            if(groupCountMap.contains(left)){
              leftCount=groupCountMap(left)
              println("跳过------------")
            }else{
              leftCount=dataFrame.groupBy(left.toList.head,left.toList:_*).count().count()
              groupCountMap.put(left,leftCount)
            }
            if(leftCount>=groupCountMap(right)){
              val all=left++right
              if(groupCountMap.contains(all)){
                allCount=groupCountMap(all)
                println("跳过------------")
              }else{
                allCount=dataFrame.groupBy(right.toList.head,all.toList:_*).count().count()
                groupCountMap.put(all,allCount)
              }
              if(allCount==leftCount){
                if(functionMap.contains(rightStr)){
                  functionMap(rightStr)=functionMap(rightStr).+=(left)
                  removeSet=removeSet.+=(left)
                }else{
                  var initSet=new mutable.ListBuffer[mutable.HashSet[String]]()
                  functionMap.put(rightStr,initSet.+=(left))
                  removeSet=removeSet.+=(left)
                }
              }
            }

          })

          val currItemCount=currColSets.toList.head.size
          var nextArr=currColSets.filter(!removeSet.contains(_)).combinations(2).map(x=>{
            x(0) ++ x(1)
          })
          val tmpRdd=sc.parallelize(nextArr.toSeq).repartition(111).persist()


          println(removeSet)
          val broadcastedRemoveSet=sc.broadcast(removeSet)
          val newcurr=tmpRdd.filter(newSet=>{
            var flag=true
            if(newSet.size!=currItemCount+1){
              flag=false
            }else{
              for(item<- broadcastedRemoveSet.value if flag){
                if(item.subsetOf(newSet)){
                  flag=false
                }
              }
            }

            flag
          }).collect()
          broadcastedRemoveSet.destroy()
          currColSets=new mutable.ArrayBuffer[mutable.HashSet[String]]()
          currColSets=currColSets++newcurr
          tmpRdd.unpersist()
          println("第"+currItemCount+"层")
        }
      }
      functionMap.foreach(x=>{
        x._2.foreach(y=>{
          if(reFunctionMap.contains(y)){
            reFunctionMap(y)=reFunctionMap(y).+=(x._1)
          }else{
            val tmp=new mutable.ListBuffer[String]
            reFunctionMap.put(y,tmp.+=(x._1))
          }
        })
      })
      var result=""
      reFunctionMap.foreach(x=>{
        result=result+x._1.toArray.sortWith((a,b)=>{
          val aint=a.split("c")(1).toInt
          val bint=b.split("c")(1).toInt
          a<b
        }).map(nameMap).mkString("[",",","]")+":"+x._2.sortWith((a,b)=>{
          val aint=a.split("c")(1).toInt
          val bint=b.split("c")(1).toInt
          a<b
        }).map(nameMap).mkString(",")+"\n"


      })

      println("----------------------end------------------")
      sc.parallelize(Array(result)).repartition(111).saveAsTextFile(outputFileUrl)

    }


  }



  //获得分组
  def getGroups(colPair:mutable.HashMap[String,Long]):mutable.HashMap[Long,mutable.HashMap[Long,util.ArrayList[Long]]]={
    val colCount=colPair.size
    val canGroups=new mutable.HashMap[Long,mutable.HashMap[Long,util.ArrayList[Long]]]()
    var past=0L

    for(i <- 1 to colCount) {
      val candidates=createCandidates(colPair)
      val num = colPair("_c" + (i - 1))
      //筛选包含共同分组的候选项
      val canGroup = candidates.filter(cans => {
        var flag:Boolean=true
        if((cans._1&num)==0L||(past&cans._1)!=0L){
          flag=false
        }
        flag
      })
      canGroups += (num -> canGroup)
      past+=num
    }
    canGroups
  }


  def translateCandidates(canGroups: mutable.HashMap[Long,mutable.HashMap[Long,util.ArrayList[Long]]],colPair:mutable.HashMap[String,Long],outputFileUrl:String,sc:SparkContext):Unit={
    canGroups.foreach(candidates=>{
      candidates._2.foreach(f=>{
        if(f._2.size()>0){

          var keyString=""
          var valueString=""
          colPair.foreach(l=>{
            if((l._2&f._1)!=0L){
              val index=(Math.log(l._2) /Math.log(2)+1).asInstanceOf[Number].intValue()
              keyString+=("Column"+index+",")
            }
          })

          for(n<-0 to f._2.size()-1){
            val index=(Math.log(f._2.get(n)) /Math.log(2)+1).asInstanceOf[Number].intValue()
            valueString+=("Column"+index+",")
          }

          result+=("["+keyString.substring(0,keyString.length-1)+"]:"+ valueString.substring(0,valueString.length-1)+"\n")

        }
      })
    })
    //将结果保存到hdfs
    sc.parallelize(Array(result).toSeq).saveAsTextFile(outputFileUrl)

  }


  //从csv中读取数据并放到dataframe中
  def readDataFromCsv(filePathUri:String,sparkContext:SparkContext):DataFrame={
    val sqlContext = new SQLContext(sparkContext)
    val data =sqlContext.read.format("com.databricks.spark.csv")
      .option("header","false") //这里如果在csv第一行有属性的话，没有就是"false"
      .option("inferSchema",true.toString)//这是自动推断属性列的数据类型。
      .load(filePathUri)//文件的路径
    data
  }



  //构建候选函数依赖集
  def createCandidates(colPair:mutable.HashMap[String,Long]):mutable.HashMap[Long,util.ArrayList[Long]]={
    val candidates:mutable.HashMap[Long,util.ArrayList[Long]]=new mutable.HashMap[Long,util.ArrayList[Long]]()
    val colCount=colPair.size

    var leftCount=(Math.pow(2,colCount)-2).asInstanceOf[Number].longValue()
    var i=1L
    while(i<leftCount){
      val values=new util.ArrayList[Long]()
      for(j<- 0 to colCount-1){
        val value=colPair.get("_c"+j).get
        if((value & i)==0L){
          values.add(value)
        }
      }
      candidates.put(i,values)
      i+=1L
    }
    candidates
  }
  //用唯一二进制数表示每一列
  def getColFlag(colCount:Int):mutable.HashMap[String,Long] ={
    var tmp:Long=1L
    val colPair=new mutable.HashMap[String,Long]()
    for(i<-0 to colCount-1){
      colPair.put("_c"+i,tmp)
      tmp=tmp<<1
    }
    colPair
  }


  //验证候选项
  def FD_discover(candidates: mutable.HashMap[Long,util.ArrayList[Long]], dataFrame: DataFrame, colFlag:mutable.HashMap[String,Long], repeatCol:String)={
    val colCount=dataFrame.columns.length

    candidates.foreach(f=>{
      breakable {
        if(f._2.size()==0){
          break()
        }
        val listString=new ArrayBuffer[String]()
        colFlag.foreach(l=>{
          if((f._1&l._2)!=0L){
            listString+=l._1
          }
        })

        //获得左部属性的组数
        var keyGroupCount=0L
        if(groupCountPairs.contains(f._1)){
          keyGroupCount=groupCountPairs(f._1)
        }else{
          keyGroupCount=dataFrame.groupBy(repeatCol,listString:_*).count().count()
          groupCountPairs+=(f._1->keyGroupCount)
        }
        var i=0
        //获得左+右属性的组数
        while (i<f._2.size()){
          val newlist=listString.clone()
          val value=f._2.get(i)
          val index=Math.log(value)/Math.log(2)
          newlist+="_c"+index.asInstanceOf[Number].intValue()
          var valueGroupCount=0L
          if(groupCountPairs.contains(f._1|value)){
            valueGroupCount=groupCountPairs(f._1 + value)
          }else{
            valueGroupCount=dataFrame.groupBy(repeatCol,newlist:_*).count().count()
            groupCountPairs+=((f._1|value)->valueGroupCount)
          }

          if(valueGroupCount!=keyGroupCount){
            f._2.remove(i)
            //向下剪枝
            candidates.foreach(m=>{
              if((m._1|f._1)==f._1){
                if(m._2.contains(value)){
                  m._2.remove(value)
                }
              }

            })

          }else{
            //获取最小
            canGroups.foreach(candidates=>{
              candidates._2.foreach(m=>{
                if(((m._1|f._1)==m._1)&&(m._1!=f._1)){
                  if(m._2.contains(value)){
                    m._2.remove(value)
                  }
                }

              })
            })

            i+=1
          }

        }

      }})
  }


}